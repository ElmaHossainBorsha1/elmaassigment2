
package com.example.cse438movieappfall;

import java.io.Serializable;
import java.util.List;
import javax.annotation.Generated;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.Parcelable.Creator;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Borshaassignment2 implements Serializable, Parcelable
{

    @SerializedName("id")
    @Expose
    private long id;
    @SerializedName("cast")
    @Expose
    private List<Cast> cast = null;
    @SerializedName("crew")
    @Expose
    private List<Crew> crew = null;
    public final static Creator<Borshaassignment2> CREATOR = new Creator<Borshaassignment2>() {


        @SuppressWarnings({
            "unchecked"
        })
        public Borshaassignment2 createFromParcel(android.os.Parcel in) {
            return new Borshaassignment2(in);
        }

        public Borshaassignment2 [] newArray(int size) {
            return (new Borshaassignment2[size]);
        }

    }
    ;
    private final static long serialVersionUID = -7925425528408090008L;

    protected Borshaassignment2(android.os.Parcel in) {
        this.id = ((long) in.readValue((long.class.getClassLoader())));
        in.readList(this.cast, (Cast.class.getClassLoader()));
        in.readList(this.crew, (Crew.class.getClassLoader()));
    }

    public Borshaassignment2() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Cast> getCast() {
        return cast;
    }

    public void setCast(List<Cast> cast) {
        this.cast = cast;
    }

    public List<Crew> getCrew() {
        return crew;
    }

    public void setCrew(List<Crew> crew) {
        this.crew = crew;
    }

    public void writeToParcel(android.os.Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeList(cast);
        dest.writeList(crew);
    }

    public int describeContents() {
        return  0;
    }

}
